// GENERATED FILE. Run tools/build-registry.ps1 after adding or removing an extension.
(function(){
Lingshi.registerManifest({"id":"content.personal-defaults","name":"个人默认内容","version":"1.0.0","type":"content","description":"竹间默认任务与心愿数据","entry":"entry.js","dependencies":["task.standard","product.lifestyle"],"optionalDependencies":[],"assets":[],"capabilities":["data.seed"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/content/personal-defaults/entry.js"><\/script>');
Lingshi.registerManifest({"id":"page.personal-dashboard","name":"个人灵石页面","version":"1.0.0","type":"page","description":"今日、心愿、衣境阁与拾光页面","entry":"entry.js","dependencies":["task.standard","product.lifestyle","product.theme-unlock","statistics.basic"],"optionalDependencies":[],"assets":[],"capabilities":["page.register","ui.slot","task.read","shop.read","theme.read"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/pages/personal-dashboard/entry.js"><\/script>');
Lingshi.registerManifest({"id":"product.lifestyle","name":"生活心愿类型","version":"1.0.0","type":"product-type","description":"现金、休息时长、许可与自定义心愿","entry":"entry.js","dependencies":[],"optionalDependencies":[],"assets":[],"capabilities":["shop.product-type"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/product-types/lifestyle/entry.js"><\/script>');
Lingshi.registerManifest({"id":"product.theme-unlock","name":"主题解锁商品","version":"1.0.0","type":"product-type","description":"以灵石限时解锁主题","entry":"entry.js","dependencies":[],"optionalDependencies":[],"assets":[],"capabilities":["shop.product-type","theme.grant"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/product-types/theme-unlock/entry.js"><\/script>');
Lingshi.registerManifest({"id":"statistics.basic","name":"基础拾光统计","version":"1.0.0","type":"statistics","description":"基于事件与交易记录生成基础统计","entry":"entry.js","dependencies":[],"optionalDependencies":[],"assets":[],"capabilities":["statistics.card","events.listen"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/statistics/basic/entry.js"><\/script>');
Lingshi.registerManifest({"id":"system.editor","name":"墨房编辑系统","version":"1.0.0","type":"system","description":"界面编辑、配置导入、差异预览与架构说明","entry":"entry.js","dependencies":["task.standard","product.lifestyle"],"optionalDependencies":[],"assets":[],"capabilities":["settings.section","config.read","config.write","extension.inspect"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/systems/editor/entry.js"><\/script>');
Lingshi.registerManifest({"id":"system.theme-commerce","name":"主题商城桥接","version":"1.0.0","type":"system","description":"根据主题清单自动生成主题商品","entry":"entry.js","dependencies":["product.theme-unlock"],"optionalDependencies":[],"assets":[],"capabilities":["events.listen","shop.write","theme.read"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/systems/theme-commerce/entry.js"><\/script>');
Lingshi.registerManifest({"id":"task.standard","name":"标准修行任务","version":"1.0.0","type":"task-type","description":"提供学习、强化自己与付出类的标准任务","entry":"entry.js","dependencies":[],"optionalDependencies":[],"assets":[],"capabilities":["task.type"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/task-types/standard/entry.js"><\/script>');
Lingshi.registerManifest({"id":"theme.anime","name":"樱庭绘卷","version":"1.1.0","type":"theme","description":"完整二次元美少女主题与动态花瓣","entry":"entry.js","dependencies":[],"optionalDependencies":[],"assets":["../assets/anime-sakura-hero.png"],"capabilities":["theme.tokens","theme.background","theme.decoration","theme.animation","theme.character"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/themes/anime/entry.js"><\/script>');
Lingshi.registerManifest({"id":"theme.bamboo-day","name":"竹间清昼","version":"1.0.0","type":"theme","description":"默认竹青与淡金主题","entry":"entry.js","dependencies":[],"optionalDependencies":[],"assets":[],"capabilities":["theme.tokens"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/themes/bamboo-day/entry.js"><\/script>');
Lingshi.registerManifest({"id":"theme.bamboo-night","name":"夜竹藏金","version":"1.0.0","type":"theme","description":"免费深竹夜色主题","entry":"entry.js","dependencies":[],"optionalDependencies":[],"assets":[],"capabilities":["theme.tokens","theme.decoration"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/themes/bamboo-night/entry.js"><\/script>');
Lingshi.registerManifest({"id":"theme.cyberpunk","name":"霓虹竹城","version":"1.1.0","type":"theme","description":"赛博夜雨、鎏金电路与动态数据流","entry":"entry.js","dependencies":[],"optionalDependencies":[],"assets":["../assets/cyber-bamboo-city.png"],"capabilities":["theme.tokens","theme.background","theme.decoration","theme.animation","theme.sound"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/themes/cyberpunk/entry.js"><\/script>');
Lingshi.registerManifest({"id":"theme.inkwash","name":"山水未央","version":"1.1.0","type":"theme","description":"宣纸山水、矿物暗金与流动云雾","entry":"entry.js","dependencies":[],"optionalDependencies":[],"assets":["../assets/ink-mountain-scroll.png"],"capabilities":["theme.tokens","theme.background","theme.decoration","theme.animation"],"compatibleCoreVersion":"^1.0.0","enabled":true});
document.write('<script src="./extensions/themes/inkwash/entry.js"><\/script>');
})();
